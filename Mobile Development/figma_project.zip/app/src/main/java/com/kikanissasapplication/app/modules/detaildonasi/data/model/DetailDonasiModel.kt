package com.kikanissasapplication.app.modules.detaildonasi.`data`.model

import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.di.MyApp
import kotlin.String

data class DetailDonasiModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtBantuanLongsor: String? =
      MyApp.getInstance().resources.getString(R.string.msg_bantuan_longsor2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGerejaKatolik: String? =
      MyApp.getInstance().resources.getString(R.string.msg_gereja_katolik)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTanggalMulai: String? = MyApp.getInstance().resources.getString(R.string.lbl_tanggal_mulai)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTanggal: String? = MyApp.getInstance().resources.getString(R.string.lbl_5_oktober_2023)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTanggalSelesai: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_tanggal_selesai)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSelesai: String? = MyApp.getInstance().resources.getString(R.string.lbl_9_november_2023)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDanaTerkumpul: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_dana_terkumpul)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtRpCounter: String? = MyApp.getInstance().resources.getString(R.string.lbl_rp_7_780_0002)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtRincianPenggun: String? =
      MyApp.getInstance().resources.getString(R.string.msg_rincian_penggun)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDanaUntukPeng: String? =
      MyApp.getInstance().resources.getString(R.string.msg_dana_untuk_peng)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtRpCounterOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_rp_7_780_0002)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBiayatransaksi: String? =
      MyApp.getInstance().resources.getString(R.string.msg_biaya_transaksi)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBiaya: String? = MyApp.getInstance().resources.getString(R.string.lbl_rp86_000)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSudahDicairkan: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_sudah_dicairkan)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCair: String? = MyApp.getInstance().resources.getString(R.string.lbl_rp4_425_000)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBelumDicairkan: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_belum_dicairkan)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBelumcair: String? = MyApp.getInstance().resources.getString(R.string.lbl_rp2_695_000)

)
