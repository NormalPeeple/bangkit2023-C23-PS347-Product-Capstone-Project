package com.kikanissasapplication.app.modules.berandapengurus.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.base.BaseActivity
import com.kikanissasapplication.app.databinding.ActivityBerandaPengurusBinding
import com.kikanissasapplication.app.modules.berandapengurus.`data`.viewmodel.BerandaPengurusVM
import com.kikanissasapplication.app.modules.catatankeuangan.ui.CatatanKeuanganActivity
import com.kikanissasapplication.app.modules.listsedekah.ui.ListSedekahActivity
import com.kikanissasapplication.app.modules.listsedekahone.ui.ListSedekahOneActivity
import com.kikanissasapplication.app.modules.pengajuanacara.ui.PengajuanAcaraActivity
import kotlin.String
import kotlin.Unit

class BerandaPengurusActivity :
    BaseActivity<ActivityBerandaPengurusBinding>(R.layout.activity_beranda_pengurus) {
  private val viewModel: BerandaPengurusVM by viewModels<BerandaPengurusVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.berandaPengurusVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.frameStacklaptop.setOnClickListener {
      val destIntent = ListSedekahActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearRowmap.setOnClickListener {
      val destIntent = ListSedekahOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearRowtrash.setOnClickListener {
      val destIntent = PengajuanAcaraActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearRowfile.setOnClickListener {
      val destIntent = CatatanKeuanganActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
  }

  companion object {
    const val TAG: String = "BERANDA_PENGURUS_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, BerandaPengurusActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
