package com.kikanissasapplication.app.modules.listdonasione.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.databinding.RowListrectanglefiftyoneBinding
import com.kikanissasapplication.app.modules.listdonasione.`data`.model.ListrectanglefiftyoneRowModel
import kotlin.Int
import kotlin.collections.List

class ListrectanglefiftyoneAdapter(
  var list: List<ListrectanglefiftyoneRowModel>
) : RecyclerView.Adapter<ListrectanglefiftyoneAdapter.RowListrectanglefiftyoneVH>() {
  private var clickListener: OnItemClickListener? = null

  override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowListrectanglefiftyoneVH {
    val
        view=LayoutInflater.from(parent.context).inflate(R.layout.row_listrectanglefiftyone,parent,false)
    return RowListrectanglefiftyoneVH(view)
  }

  override fun onBindViewHolder(holder: RowListrectanglefiftyoneVH, position: Int) {
    val listrectanglefiftyoneRowModel = ListrectanglefiftyoneRowModel()
    // TODO uncomment following line after integration with data source
    // val listrectanglefiftyoneRowModel = list[position]
    holder.binding.listrectanglefiftyoneRowModel = listrectanglefiftyoneRowModel
  }

  override fun getItemCount(): Int = 6
  // TODO uncomment following line after integration with data source
  // return list.size

  public fun updateData(newData: List<ListrectanglefiftyoneRowModel>) {
    list = newData
    notifyDataSetChanged()
  }

  fun setOnItemClickListener(clickListener: OnItemClickListener) {
    this.clickListener = clickListener
  }

  interface OnItemClickListener {
    fun onItemClick(
      view: View,
      position: Int,
      item: ListrectanglefiftyoneRowModel
    ) {
    }
  }

  inner class RowListrectanglefiftyoneVH(
    view: View
  ) : RecyclerView.ViewHolder(view) {
    val binding: RowListrectanglefiftyoneBinding = RowListrectanglefiftyoneBinding.bind(itemView)
    init {
      binding.linearRowrectanglefiftyone.setOnClickListener {
        // TODO replace with value from datasource
        clickListener?.onItemClick(it, adapterPosition, ListrectanglefiftyoneRowModel())
      }
    }
  }
}
