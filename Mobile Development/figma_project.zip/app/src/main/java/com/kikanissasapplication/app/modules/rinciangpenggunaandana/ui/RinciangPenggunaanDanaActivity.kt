package com.kikanissasapplication.app.modules.rinciangpenggunaandana.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.base.BaseActivity
import com.kikanissasapplication.app.databinding.ActivityRinciangPenggunaanDanaBinding
import com.kikanissasapplication.app.modules.rinciangpenggunaandana.`data`.viewmodel.RinciangPenggunaanDanaVM
import com.kikanissasapplication.app.modules.updatesedekahsedekah.ui.UpdateSedekahSedekahActivity
import kotlin.String
import kotlin.Unit

class RinciangPenggunaanDanaActivity :
    BaseActivity<ActivityRinciangPenggunaanDanaBinding>(R.layout.activity_rinciang_penggunaan_dana)
    {
  private val viewModel: RinciangPenggunaanDanaVM by viewModels<RinciangPenggunaanDanaVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.rinciangPenggunaanDanaVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.btnUpdatePenggunaanDana.setOnClickListener {
      val destIntent = UpdateSedekahSedekahActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "RINCIANG_PENGGUNAAN_DANA_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, RinciangPenggunaanDanaActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
