package com.kikanissasapplication.app.modules.registrasijamaah.`data`.model

import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.di.MyApp
import kotlin.String

data class RegistrasiJamaahModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtRegistrasi: String? = MyApp.getInstance().resources.getString(R.string.lbl_registrasi)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNamaLengkap: String? = MyApp.getInstance().resources.getString(R.string.lbl_nama_lengkap)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAgama: String? = MyApp.getInstance().resources.getString(R.string.lbl_agama)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDaerahKotaD: String? = MyApp.getInstance().resources.getString(R.string.msg_daerah_kota_d)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtEmail: String? = MyApp.getInstance().resources.getString(R.string.lbl_email)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNomorTelpon: String? = MyApp.getInstance().resources.getString(R.string.lbl_nomor_telpon)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNamaPengguna: String? = MyApp.getInstance().resources.getString(R.string.lbl_nama_pengguna)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtKataSandi: String? = MyApp.getInstance().resources.getString(R.string.lbl_kata_sandi)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var etUsernameValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etUsernameOneValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etUsernameTwoValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etUsernameThreeValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etUsernameFourValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etUsernameFiveValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etUsernameSixValue: String? = null
)
