package com.kikanissasapplication.app.modules.detaildonasi.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.base.BaseActivity
import com.kikanissasapplication.app.databinding.ActivityDetailDonasiBinding
import com.kikanissasapplication.app.modules.detaildonasi.`data`.viewmodel.DetailDonasiVM
import com.kikanissasapplication.app.modules.listdonasi.ui.ListDonasiActivity
import kotlin.String
import kotlin.Unit

class DetailDonasiActivity :
    BaseActivity<ActivityDetailDonasiBinding>(R.layout.activity_detail_donasi) {
  private val viewModel: DetailDonasiVM by viewModels<DetailDonasiVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.detailDonasiVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.btnDonasiSekarangOne.setOnClickListener {
      val destIntent = ListDonasiActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "DETAIL_DONASI_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, DetailDonasiActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
