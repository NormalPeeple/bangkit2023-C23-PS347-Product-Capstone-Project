package com.kikanissasapplication.app.modules.rinciangpenggunaandana.`data`.model

import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.di.MyApp
import kotlin.String

data class RinciangPenggunaanDanaModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtSantunanHafidz: String? =
      MyApp.getInstance().resources.getString(R.string.msg_santunan_hafidz)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMasjidAlIkhla: String? =
      MyApp.getInstance().resources.getString(R.string.msg_masjid_al_ikhla)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTanggalMulai: String? = MyApp.getInstance().resources.getString(R.string.lbl_tanggal_mulai)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMulai: String? = MyApp.getInstance().resources.getString(R.string.lbl_5_oktober_2023)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTanggalSelesai: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_tanggal_selesai)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSelesai: String? = MyApp.getInstance().resources.getString(R.string.lbl_1_januari_2024)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDanaTerkumpul: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_dana_terkumpul)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDana: String? = MyApp.getInstance().resources.getString(R.string.lbl_rp_12_575_240)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtRincianPenggun: String? =
      MyApp.getInstance().resources.getString(R.string.msg_rincian_penggun)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDanaUntukPeng: String? =
      MyApp.getInstance().resources.getString(R.string.msg_dana_untuk_peng)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDanapenggalang: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_rp12_575_2402)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBiayatransaksi: String? =
      MyApp.getInstance().resources.getString(R.string.msg_biaya_transaksi)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBiaya: String? = MyApp.getInstance().resources.getString(R.string.lbl_rp86_000)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSudahDicairkan: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_sudah_dicairkan)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDanacair: String? = MyApp.getInstance().resources.getString(R.string.lbl_rp5_125_000)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBelumDicairkan: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_belum_dicairkan)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDanablmcair: String? = MyApp.getInstance().resources.getString(R.string.lbl_rp7_364_420)

)
