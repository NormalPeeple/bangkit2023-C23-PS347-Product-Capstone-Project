package com.kikanissasapplication.app.modules.berandapengurus.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.kikanissasapplication.app.modules.berandapengurus.`data`.model.BerandaPengurusModel
import org.koin.core.KoinComponent

class BerandaPengurusVM : ViewModel(), KoinComponent {
  val berandaPengurusModel: MutableLiveData<BerandaPengurusModel> =
      MutableLiveData(BerandaPengurusModel())

  var navArguments: Bundle? = null
}
