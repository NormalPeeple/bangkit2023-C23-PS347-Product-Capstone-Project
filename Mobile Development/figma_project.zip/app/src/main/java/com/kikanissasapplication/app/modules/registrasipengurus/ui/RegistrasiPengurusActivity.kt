package com.kikanissasapplication.app.modules.registrasipengurus.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.base.BaseActivity
import com.kikanissasapplication.app.databinding.ActivityRegistrasiPengurusBinding
import com.kikanissasapplication.app.modules.loginpagethree.ui.LoginPageThreeActivity
import com.kikanissasapplication.app.modules.registrasipengurus.`data`.viewmodel.RegistrasiPengurusVM
import kotlin.String
import kotlin.Unit

class RegistrasiPengurusActivity :
    BaseActivity<ActivityRegistrasiPengurusBinding>(R.layout.activity_registrasi_pengurus) {
  private val viewModel: RegistrasiPengurusVM by viewModels<RegistrasiPengurusVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.registrasiPengurusVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.viewRegistrasiPeng.setOnClickListener {
      val destIntent = LoginPageThreeActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "REGISTRASI_PENGURUS_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, RegistrasiPengurusActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
