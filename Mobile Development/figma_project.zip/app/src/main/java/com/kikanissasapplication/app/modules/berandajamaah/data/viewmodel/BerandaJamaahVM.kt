package com.kikanissasapplication.app.modules.berandajamaah.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.kikanissasapplication.app.modules.berandajamaah.`data`.model.BerandaJamaahModel
import org.koin.core.KoinComponent

class BerandaJamaahVM : ViewModel(), KoinComponent {
  val berandaJamaahModel: MutableLiveData<BerandaJamaahModel> =
      MutableLiveData(BerandaJamaahModel())

  var navArguments: Bundle? = null
}
