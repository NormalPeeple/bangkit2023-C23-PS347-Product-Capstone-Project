package com.kikanissasapplication.app.modules.updatesedekahsedekah.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.kikanissasapplication.app.modules.updatesedekahsedekah.`data`.model.UpdateSedekahSedekahModel
import org.koin.core.KoinComponent

class UpdateSedekahSedekahVM : ViewModel(), KoinComponent {
  val updateSedekahSedekahModel: MutableLiveData<UpdateSedekahSedekahModel> =
      MutableLiveData(UpdateSedekahSedekahModel())

  var navArguments: Bundle? = null
}
