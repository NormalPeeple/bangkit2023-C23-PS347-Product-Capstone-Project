package com.kikanissasapplication.app.modules.detailkeluhan.`data`.model

import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.di.MyApp
import kotlin.String

data class DetailKeluhanModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtKeluhan: String? = MyApp.getInstance().resources.getString(R.string.lbl_keluhan)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNamaKeluhan: String? = MyApp.getInstance().resources.getString(R.string.lbl_nama_keluhan)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtToiletRusak: String? = MyApp.getInstance().resources.getString(R.string.lbl_toilet_rusak)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPelapor: String? = MyApp.getInstance().resources.getString(R.string.lbl_pelapor)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAbdulJaenal: String? = MyApp.getInstance().resources.getString(R.string.lbl_abdul_jaenal)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDeskripsi: String? = MyApp.getInstance().resources.getString(R.string.lbl_deskripsi)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtToiletrusakda: String? =
      MyApp.getInstance().resources.getString(R.string.msg_toilet_rusak_da2)

)
