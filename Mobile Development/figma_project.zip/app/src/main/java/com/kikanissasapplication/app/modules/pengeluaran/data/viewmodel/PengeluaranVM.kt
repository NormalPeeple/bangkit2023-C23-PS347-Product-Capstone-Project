package com.kikanissasapplication.app.modules.pengeluaran.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.kikanissasapplication.app.modules.pengeluaran.`data`.model.PengeluaranModel
import org.koin.core.KoinComponent

class PengeluaranVM : ViewModel(), KoinComponent {
  val pengeluaranModel: MutableLiveData<PengeluaranModel> = MutableLiveData(PengeluaranModel())

  var navArguments: Bundle? = null
}
