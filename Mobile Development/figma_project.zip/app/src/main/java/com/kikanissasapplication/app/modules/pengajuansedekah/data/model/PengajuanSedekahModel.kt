package com.kikanissasapplication.app.modules.pengajuansedekah.`data`.model

import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.di.MyApp
import kotlin.String

data class PengajuanSedekahModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtPengajuanSedek: String? =
      MyApp.getInstance().resources.getString(R.string.msg_pengajuan_sedek)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNamaSedekah: String? = MyApp.getInstance().resources.getString(R.string.lbl_nama_sedekah)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTanggalMulaiP: String? =
      MyApp.getInstance().resources.getString(R.string.msg_tanggal_mulai_p)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTanggalSelesai: String? =
      MyApp.getInstance().resources.getString(R.string.msg_tanggal_selesai)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDeskipsi: String? = MyApp.getInstance().resources.getString(R.string.lbl_deskipsi)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtExMasjidAl: String? = MyApp.getInstance().resources.getString(R.string.msg_ex_masjid_al2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtUnggahFoto: String? = MyApp.getInstance().resources.getString(R.string.lbl_unggah_foto)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var etUsernameValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etUsernameOneValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etUsernameTwoValue: String? = null
)
