package com.kikanissasapplication.app.modules.registrasijamaah.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.kikanissasapplication.app.modules.registrasijamaah.`data`.model.RegistrasiJamaahModel
import org.koin.core.KoinComponent

class RegistrasiJamaahVM : ViewModel(), KoinComponent {
  val registrasiJamaahModel: MutableLiveData<RegistrasiJamaahModel> =
      MutableLiveData(RegistrasiJamaahModel())

  var navArguments: Bundle? = null
}
