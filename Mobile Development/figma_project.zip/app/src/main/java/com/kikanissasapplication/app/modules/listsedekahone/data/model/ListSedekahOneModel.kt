package com.kikanissasapplication.app.modules.listsedekahone.`data`.model

import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.di.MyApp
import kotlin.String

data class ListSedekahOneModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtPengajuanSedek: String? =
      MyApp.getInstance().resources.getString(R.string.msg_pengajuan_sedek)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDaftarPengajua: String? =
      MyApp.getInstance().resources.getString(R.string.msg_daftar_pengajua)

)
