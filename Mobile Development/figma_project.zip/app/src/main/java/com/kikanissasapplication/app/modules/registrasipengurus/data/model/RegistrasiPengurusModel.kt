package com.kikanissasapplication.app.modules.registrasipengurus.`data`.model

class RegistrasiPengurusModel()
