package com.kikanissasapplication.app.modules.catatankeuangan.`data`.model

import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.di.MyApp
import kotlin.String

data class CatatanKeuanganModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtCatatanKeuanga: String? =
      MyApp.getInstance().resources.getString(R.string.msg_catatan_keuanga)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPemasukan: String? = MyApp.getInstance().resources.getString(R.string.lbl_pemasukan)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDanapemasukan: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_rp50_321_000_00)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSaldoMasjid: String? = MyApp.getInstance().resources.getString(R.string.lbl_saldo_masjid)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSaldo: String? = MyApp.getInstance().resources.getString(R.string.lbl_rp25_321_000_00)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPengeluaran: String? = MyApp.getInstance().resources.getString(R.string.lbl_pengeluaran)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDanapengeluaran: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_rp25_000_000_00)

)
