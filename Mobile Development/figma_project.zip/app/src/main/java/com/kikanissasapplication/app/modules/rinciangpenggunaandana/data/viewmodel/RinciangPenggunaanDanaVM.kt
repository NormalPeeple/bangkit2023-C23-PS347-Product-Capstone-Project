package com.kikanissasapplication.app.modules.rinciangpenggunaandana.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.kikanissasapplication.app.modules.rinciangpenggunaandana.`data`.model.RinciangPenggunaanDanaModel
import org.koin.core.KoinComponent

class RinciangPenggunaanDanaVM : ViewModel(), KoinComponent {
  val rinciangPenggunaanDanaModel: MutableLiveData<RinciangPenggunaanDanaModel> =
      MutableLiveData(RinciangPenggunaanDanaModel())

  var navArguments: Bundle? = null
}
