package com.kikanissasapplication.app.modules.updatesedekahsedekah.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.base.BaseActivity
import com.kikanissasapplication.app.databinding.ActivityUpdateSedekahSedekahBinding
import com.kikanissasapplication.app.modules.listsedekahone.ui.ListSedekahOneActivity
import com.kikanissasapplication.app.modules.updatesedekahsedekah.`data`.viewmodel.UpdateSedekahSedekahVM
import kotlin.String
import kotlin.Unit

class UpdateSedekahSedekahActivity :
    BaseActivity<ActivityUpdateSedekahSedekahBinding>(R.layout.activity_update_sedekah_sedekah) {
  private val viewModel: UpdateSedekahSedekahVM by viewModels<UpdateSedekahSedekahVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.updateSedekahSedekahVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
    binding.btnUpdate.setOnClickListener {
      val destIntent = ListSedekahOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "UPDATE_SEDEKAH_SEDEKAH_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, UpdateSedekahSedekahActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
