package com.kikanissasapplication.app.modules.pengajuanacara.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.base.BaseActivity
import com.kikanissasapplication.app.databinding.ActivityPengajuanAcaraBinding
import com.kikanissasapplication.app.modules.pengajuanacara.`data`.viewmodel.PengajuanAcaraVM
import kotlin.String
import kotlin.Unit

class PengajuanAcaraActivity :
    BaseActivity<ActivityPengajuanAcaraBinding>(R.layout.activity_pengajuan_acara) {
  private val viewModel: PengajuanAcaraVM by viewModels<PengajuanAcaraVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.pengajuanAcaraVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
  }

  companion object {
    const val TAG: String = "PENGAJUAN_ACARA_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, PengajuanAcaraActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
