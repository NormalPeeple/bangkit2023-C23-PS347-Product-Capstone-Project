package com.kikanissasapplication.app.modules.berandajamaah.`data`.model

import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.di.MyApp
import kotlin.String

data class BerandaJamaahModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtBeranda: String? = MyApp.getInstance().resources.getString(R.string.lbl_beranda)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtRekomendasiTem: String? =
      MyApp.getInstance().resources.getString(R.string.msg_rekomendasi_te)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSedekahOnline: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_sedekah_online)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtKeluhan: String? = MyApp.getInstance().resources.getString(R.string.lbl_keluhan)

)
