package com.kikanissasapplication.app.modules.listdonasi.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.kikanissasapplication.app.modules.listdonasi.`data`.model.ListDonasiModel
import org.koin.core.KoinComponent

class ListDonasiVM : ViewModel(), KoinComponent {
  val listDonasiModel: MutableLiveData<ListDonasiModel> = MutableLiveData(ListDonasiModel())

  var navArguments: Bundle? = null
}
