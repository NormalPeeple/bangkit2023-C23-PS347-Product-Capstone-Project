package com.kikanissasapplication.app.modules.loginpagetwo.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.base.BaseActivity
import com.kikanissasapplication.app.databinding.ActivityLoginPageTwoBinding
import com.kikanissasapplication.app.modules.loginpagetwo.`data`.viewmodel.LoginPageTwoVM
import com.kikanissasapplication.app.modules.registrasijamaah.ui.RegistrasiJamaahActivity
import com.kikanissasapplication.app.modules.registrasipengurus.ui.RegistrasiPengurusActivity
import kotlin.String
import kotlin.Unit

class LoginPageTwoActivity :
    BaseActivity<ActivityLoginPageTwoBinding>(R.layout.activity_login_page_two) {
  private val viewModel: LoginPageTwoVM by viewModels<LoginPageTwoVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.loginPageTwoVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.linearRowsave.setOnClickListener {
      val destIntent = RegistrasiJamaahActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearRowhome.setOnClickListener {
      val destIntent = RegistrasiPengurusActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "LOGIN_PAGE_TWO_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, LoginPageTwoActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
