package com.kikanissasapplication.app.modules.pemasukan.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.base.BaseActivity
import com.kikanissasapplication.app.databinding.ActivityPemasukanBinding
import com.kikanissasapplication.app.modules.pemasukan.`data`.viewmodel.PemasukanVM
import kotlin.String
import kotlin.Unit

class PemasukanActivity : BaseActivity<ActivityPemasukanBinding>(R.layout.activity_pemasukan) {
  private val viewModel: PemasukanVM by viewModels<PemasukanVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.pemasukanVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
  }

  companion object {
    const val TAG: String = "PEMASUKAN_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, PemasukanActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
