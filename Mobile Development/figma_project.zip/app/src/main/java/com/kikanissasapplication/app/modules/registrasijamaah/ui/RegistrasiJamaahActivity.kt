package com.kikanissasapplication.app.modules.registrasijamaah.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.base.BaseActivity
import com.kikanissasapplication.app.databinding.ActivityRegistrasiJamaahBinding
import com.kikanissasapplication.app.modules.loginpage.ui.LoginPageActivity
import com.kikanissasapplication.app.modules.registrasijamaah.`data`.viewmodel.RegistrasiJamaahVM
import kotlin.String
import kotlin.Unit

class RegistrasiJamaahActivity :
    BaseActivity<ActivityRegistrasiJamaahBinding>(R.layout.activity_registrasi_jamaah) {
  private val viewModel: RegistrasiJamaahVM by viewModels<RegistrasiJamaahVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.registrasiJamaahVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.btnDaftar.setOnClickListener {
      val destIntent = LoginPageActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "REGISTRASI_JAMAAH_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, RegistrasiJamaahActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
