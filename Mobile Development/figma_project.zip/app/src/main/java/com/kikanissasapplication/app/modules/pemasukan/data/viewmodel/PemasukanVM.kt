package com.kikanissasapplication.app.modules.pemasukan.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.kikanissasapplication.app.modules.pemasukan.`data`.model.PemasukanModel
import org.koin.core.KoinComponent

class PemasukanVM : ViewModel(), KoinComponent {
  val pemasukanModel: MutableLiveData<PemasukanModel> = MutableLiveData(PemasukanModel())

  var navArguments: Bundle? = null
}
