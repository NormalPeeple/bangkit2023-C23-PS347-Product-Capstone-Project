package com.kikanissasapplication.app.modules.loginpagethree.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.base.BaseActivity
import com.kikanissasapplication.app.databinding.ActivityLoginPageThreeBinding
import com.kikanissasapplication.app.modules.berandapengurus.ui.BerandaPengurusActivity
import com.kikanissasapplication.app.modules.loginpagethree.`data`.viewmodel.LoginPageThreeVM
import kotlin.String
import kotlin.Unit

class LoginPageThreeActivity :
    BaseActivity<ActivityLoginPageThreeBinding>(R.layout.activity_login_page_three) {
  private val viewModel: LoginPageThreeVM by viewModels<LoginPageThreeVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.loginPageThreeVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.btnMasuk.setOnClickListener {
      val destIntent = BerandaPengurusActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "LOGIN_PAGE_THREE_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, LoginPageThreeActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
