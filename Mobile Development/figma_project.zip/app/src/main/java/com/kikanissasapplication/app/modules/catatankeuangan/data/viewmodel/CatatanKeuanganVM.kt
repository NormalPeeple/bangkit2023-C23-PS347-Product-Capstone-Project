package com.kikanissasapplication.app.modules.catatankeuangan.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.kikanissasapplication.app.modules.catatankeuangan.`data`.model.CatatanKeuanganModel
import org.koin.core.KoinComponent

class CatatanKeuanganVM : ViewModel(), KoinComponent {
  val catatanKeuanganModel: MutableLiveData<CatatanKeuanganModel> =
      MutableLiveData(CatatanKeuanganModel())

  var navArguments: Bundle? = null
}
