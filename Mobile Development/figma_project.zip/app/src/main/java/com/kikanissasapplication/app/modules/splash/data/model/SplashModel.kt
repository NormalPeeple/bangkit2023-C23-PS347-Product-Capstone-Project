package com.kikanissasapplication.app.modules.splash.`data`.model

import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.di.MyApp
import kotlin.String

data class SplashModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtECI: String? = MyApp.getInstance().resources.getString(R.string.lbl_eci)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtEspacedeCulte: String? =
      MyApp.getInstance().resources.getString(R.string.msg_espace_de_culte)

)
