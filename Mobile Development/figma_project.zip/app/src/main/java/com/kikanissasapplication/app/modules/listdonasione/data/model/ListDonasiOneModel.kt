package com.kikanissasapplication.app.modules.listdonasione.`data`.model

import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.di.MyApp
import kotlin.String

data class ListDonasiOneModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtDonasi: String? = MyApp.getInstance().resources.getString(R.string.lbl_donasi)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtKategori: String? = MyApp.getInstance().resources.getString(R.string.lbl_kategori)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtUrutkan: String? = MyApp.getInstance().resources.getString(R.string.lbl_urutkan)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtRenovasiToliet: String? =
      MyApp.getInstance().resources.getString(R.string.msg_renovasi_toliet)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMasjidAlIkhla: String? =
      MyApp.getInstance().resources.getString(R.string.msg_masjid_al_ikhla)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTerkumpul: String? = MyApp.getInstance().resources.getString(R.string.lbl_terkumpul)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSisaHari: String? = MyApp.getInstance().resources.getString(R.string.lbl_sisa_hari)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtRpCounter: String? = MyApp.getInstance().resources.getString(R.string.lbl_rp_1_345_000)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHariCounter: String? = MyApp.getInstance().resources.getString(R.string.lbl_45_hari)

)
