package com.kikanissasapplication.app.modules.pengeluaran.`data`.model

import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.di.MyApp
import kotlin.String

data class PengeluaranModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtPengeluaran: String? = MyApp.getInstance().resources.getString(R.string.lbl_pengeluaran)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNamaPemasukan: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_nama_pemasukan)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNominal: String? = MyApp.getInstance().resources.getString(R.string.lbl_nominal)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtRp: String? = MyApp.getInstance().resources.getString(R.string.lbl_rp)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtKategori: String? = MyApp.getInstance().resources.getString(R.string.lbl_kategori)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var etUsernameValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etUsernameOneValue: String? = null
)
