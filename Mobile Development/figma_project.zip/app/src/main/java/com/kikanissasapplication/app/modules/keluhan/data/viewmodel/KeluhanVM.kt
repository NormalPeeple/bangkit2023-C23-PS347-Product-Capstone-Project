package com.kikanissasapplication.app.modules.keluhan.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.kikanissasapplication.app.modules.keluhan.`data`.model.KeluhanModel
import org.koin.core.KoinComponent

class KeluhanVM : ViewModel(), KoinComponent {
  val keluhanModel: MutableLiveData<KeluhanModel> = MutableLiveData(KeluhanModel())

  var navArguments: Bundle? = null
}
