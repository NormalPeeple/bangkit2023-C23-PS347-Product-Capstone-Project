package com.kikanissasapplication.app.modules.listsedekahone.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.base.BaseActivity
import com.kikanissasapplication.app.databinding.ActivityListSedekahOneBinding
import com.kikanissasapplication.app.modules.berandapengurus.ui.BerandaPengurusActivity
import com.kikanissasapplication.app.modules.listsedekahone.`data`.model.ListrectanglefortyoneRowModel
import com.kikanissasapplication.app.modules.listsedekahone.`data`.viewmodel.ListSedekahOneVM
import com.kikanissasapplication.app.modules.pengajuansedekah.ui.PengajuanSedekahActivity
import com.kikanissasapplication.app.modules.rinciangpenggunaandana.ui.RinciangPenggunaanDanaActivity
import kotlin.Int
import kotlin.String
import kotlin.Unit

class ListSedekahOneActivity :
    BaseActivity<ActivityListSedekahOneBinding>(R.layout.activity_list_sedekah_one) {
  private val viewModel: ListSedekahOneVM by viewModels<ListSedekahOneVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    val listrectanglefortyoneAdapter =
    ListrectanglefortyoneAdapter(viewModel.listrectanglefortyoneList.value?:mutableListOf())
    binding.recyclerListrectanglefortyone.adapter = listrectanglefortyoneAdapter
    listrectanglefortyoneAdapter.setOnItemClickListener(
    object : ListrectanglefortyoneAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item :
      ListrectanglefortyoneRowModel) {
        onClickRecyclerListrectanglefortyone(view, position, item)
      }
    }
    )
    viewModel.listrectanglefortyoneList.observe(this) {
      listrectanglefortyoneAdapter.updateData(it)
    }
    binding.listSedekahOneVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.linearRowarrowleft.setOnClickListener {
      val destIntent = BerandaPengurusActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.btnTambah.setOnClickListener {
      val destIntent = PengajuanSedekahActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
  }

  fun onClickRecyclerListrectanglefortyone(
    view: View,
    position: Int,
    item: ListrectanglefortyoneRowModel
  ): Unit {
    when(view.id) {
      R.id.linearRowrectanglefortyone -> {
        val destIntent = RinciangPenggunaanDanaActivity.getIntent(this, null)
        startActivity(destIntent)
      }
    }
  }

  companion object {
    const val TAG: String = "LIST_SEDEKAH_ONE_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, ListSedekahOneActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
