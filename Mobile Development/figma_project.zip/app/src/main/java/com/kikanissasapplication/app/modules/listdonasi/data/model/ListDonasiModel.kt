package com.kikanissasapplication.app.modules.listdonasi.`data`.model

import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.di.MyApp
import kotlin.String

data class ListDonasiModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtDonasiSekarang: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_donasi_sekarang)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCountry: String? = MyApp.getInstance().resources.getString(R.string.msg_bank_rakyat_ind)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCountryOne: String? = MyApp.getInstance().resources.getString(R.string.msg_bank_syariah_in)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBankCentralAs: String? =
      MyApp.getInstance().resources.getString(R.string.msg_bank_central_as)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCountryTwo: String? = MyApp.getInstance().resources.getString(R.string.msg_bank_negara_ind)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var etGroupTwentyTwoValue: String? = null
)
