package com.kikanissasapplication.app.modules.listdonasione.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.base.BaseActivity
import com.kikanissasapplication.app.databinding.ActivityListDonasiOneBinding
import com.kikanissasapplication.app.modules.detaildonasi.ui.DetailDonasiActivity
import com.kikanissasapplication.app.modules.listdonasione.`data`.model.ListrectanglefiftyoneRowModel
import com.kikanissasapplication.app.modules.listdonasione.`data`.viewmodel.ListDonasiOneVM
import kotlin.Int
import kotlin.String
import kotlin.Unit

class ListDonasiOneActivity :
    BaseActivity<ActivityListDonasiOneBinding>(R.layout.activity_list_donasi_one) {
  private val viewModel: ListDonasiOneVM by viewModels<ListDonasiOneVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    val listrectanglefiftyoneAdapter =
    ListrectanglefiftyoneAdapter(viewModel.listrectanglefiftyoneList.value?:mutableListOf())
    binding.recyclerListrectanglefiftyone.adapter = listrectanglefiftyoneAdapter
    listrectanglefiftyoneAdapter.setOnItemClickListener(
    object : ListrectanglefiftyoneAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item :
      ListrectanglefiftyoneRowModel) {
        onClickRecyclerListrectanglefiftyone(view, position, item)
      }
    }
    )
    viewModel.listrectanglefiftyoneList.observe(this) {
      listrectanglefiftyoneAdapter.updateData(it)
    }
    binding.listDonasiOneVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
  }

  fun onClickRecyclerListrectanglefiftyone(
    view: View,
    position: Int,
    item: ListrectanglefiftyoneRowModel
  ): Unit {
    when(view.id) {
      R.id.linearRowrectanglefiftyone -> {
        val destIntent = DetailDonasiActivity.getIntent(this, null)
        startActivity(destIntent)
      }
    }
  }

  companion object {
    const val TAG: String = "LIST_DONASI_ONE_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, ListDonasiOneActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
