package com.kikanissasapplication.app.modules.pengajuanacara.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.kikanissasapplication.app.modules.pengajuanacara.`data`.model.PengajuanAcaraModel
import org.koin.core.KoinComponent

class PengajuanAcaraVM : ViewModel(), KoinComponent {
  val pengajuanAcaraModel: MutableLiveData<PengajuanAcaraModel> =
      MutableLiveData(PengajuanAcaraModel())

  var navArguments: Bundle? = null
}
