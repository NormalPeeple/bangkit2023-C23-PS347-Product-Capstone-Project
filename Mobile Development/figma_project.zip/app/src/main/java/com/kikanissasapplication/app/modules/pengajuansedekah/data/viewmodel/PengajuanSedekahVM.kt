package com.kikanissasapplication.app.modules.pengajuansedekah.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.kikanissasapplication.app.modules.pengajuansedekah.`data`.model.PengajuanSedekahModel
import org.koin.core.KoinComponent

class PengajuanSedekahVM : ViewModel(), KoinComponent {
  val pengajuanSedekahModel: MutableLiveData<PengajuanSedekahModel> =
      MutableLiveData(PengajuanSedekahModel())

  var navArguments: Bundle? = null
}
