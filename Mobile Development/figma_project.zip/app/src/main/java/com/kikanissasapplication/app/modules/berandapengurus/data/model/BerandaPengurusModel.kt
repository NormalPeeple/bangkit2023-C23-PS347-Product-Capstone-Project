package com.kikanissasapplication.app.modules.berandapengurus.`data`.model

import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.di.MyApp
import kotlin.String

data class BerandaPengurusModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtBeranda: String? = MyApp.getInstance().resources.getString(R.string.lbl_beranda)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCatatanKeuanga: String? =
      MyApp.getInstance().resources.getString(R.string.msg_catatan_keuanga)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPengajuanEvent: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_pengajuan_event)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPengajuanDana: String? =
      MyApp.getInstance().resources.getString(R.string.msg_pengajuan_dana)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtKeluhan: String? = MyApp.getInstance().resources.getString(R.string.lbl_keluhan)

)
