package com.kikanissasapplication.app.modules.listdonasione.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.kikanissasapplication.app.modules.listdonasione.`data`.model.ListDonasiOneModel
import com.kikanissasapplication.app.modules.listdonasione.`data`.model.ListrectanglefiftyoneRowModel
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class ListDonasiOneVM : ViewModel(), KoinComponent {
  val listDonasiOneModel: MutableLiveData<ListDonasiOneModel> =
      MutableLiveData(ListDonasiOneModel())

  var navArguments: Bundle? = null

  val listrectanglefiftyoneList: MutableLiveData<MutableList<ListrectanglefiftyoneRowModel>> =
      MutableLiveData(mutableListOf())
}
