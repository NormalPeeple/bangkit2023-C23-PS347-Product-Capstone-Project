package com.kikanissasapplication.app.modules.berandajamaah.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.base.BaseActivity
import com.kikanissasapplication.app.databinding.ActivityBerandaJamaahBinding
import com.kikanissasapplication.app.modules.berandajamaah.`data`.viewmodel.BerandaJamaahVM
import com.kikanissasapplication.app.modules.keluhan.ui.KeluhanActivity
import com.kikanissasapplication.app.modules.listdonasione.ui.ListDonasiOneActivity
import kotlin.String
import kotlin.Unit

class BerandaJamaahActivity :
    BaseActivity<ActivityBerandaJamaahBinding>(R.layout.activity_beranda_jamaah) {
  private val viewModel: BerandaJamaahVM by viewModels<BerandaJamaahVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.berandaJamaahVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
    binding.linearRowlaptop.setOnClickListener {
      val destIntent = KeluhanActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearRowuser.setOnClickListener {
      val destIntent = ListDonasiOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "BERANDA_JAMAAH_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, BerandaJamaahActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
