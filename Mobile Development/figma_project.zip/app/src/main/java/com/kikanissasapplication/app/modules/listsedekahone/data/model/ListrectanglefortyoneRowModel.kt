package com.kikanissasapplication.app.modules.listsedekahone.`data`.model

import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.di.MyApp
import kotlin.String

data class ListrectanglefortyoneRowModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtRenovasiToliet: String? =
      MyApp.getInstance().resources.getString(R.string.msg_renovasi_toliet)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMasjidAlIkhla: String? =
      MyApp.getInstance().resources.getString(R.string.msg_masjid_al_ikhla)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTanggalSelesai: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_tanggal_selesai)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtToiletselesai: String? =
      MyApp.getInstance().resources.getString(R.string.msg_20_desember_202)

)
