package com.kikanissasapplication.app.modules.loginpage.`data`.model

import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.di.MyApp
import kotlin.String

data class LoginPageModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtECI: String? = MyApp.getInstance().resources.getString(R.string.lbl_eci)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtEspacedeCulte: String? =
      MyApp.getInstance().resources.getString(R.string.msg_espace_de_culte)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguage: String? = MyApp.getInstance().resources.getString(R.string.msg_lupa_kata_sandi)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtWemakeitsimp: String? =
      MyApp.getInstance().resources.getString(R.string.msg_belum_punya_aku)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var etGroupEightValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etPasswordValue: String? = null
)
