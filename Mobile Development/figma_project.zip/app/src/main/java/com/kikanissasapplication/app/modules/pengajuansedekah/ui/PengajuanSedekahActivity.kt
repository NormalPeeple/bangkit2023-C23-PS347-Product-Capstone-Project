package com.kikanissasapplication.app.modules.pengajuansedekah.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.base.BaseActivity
import com.kikanissasapplication.app.databinding.ActivityPengajuanSedekahBinding
import com.kikanissasapplication.app.modules.listsedekahone.ui.ListSedekahOneActivity
import com.kikanissasapplication.app.modules.pengajuansedekah.`data`.viewmodel.PengajuanSedekahVM
import kotlin.String
import kotlin.Unit

class PengajuanSedekahActivity :
    BaseActivity<ActivityPengajuanSedekahBinding>(R.layout.activity_pengajuan_sedekah) {
  private val viewModel: PengajuanSedekahVM by viewModels<PengajuanSedekahVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.pengajuanSedekahVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.btnAjukan.setOnClickListener {
      val destIntent = ListSedekahOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
  }

  companion object {
    const val TAG: String = "PENGAJUAN_SEDEKAH_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, PengajuanSedekahActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
