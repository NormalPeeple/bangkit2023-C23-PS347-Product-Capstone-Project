package com.kikanissasapplication.app.modules.listsedekahone.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.kikanissasapplication.app.modules.listsedekahone.`data`.model.ListSedekahOneModel
import com.kikanissasapplication.app.modules.listsedekahone.`data`.model.ListrectanglefortyoneRowModel
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class ListSedekahOneVM : ViewModel(), KoinComponent {
  val listSedekahOneModel: MutableLiveData<ListSedekahOneModel> =
      MutableLiveData(ListSedekahOneModel())

  var navArguments: Bundle? = null

  val listrectanglefortyoneList: MutableLiveData<MutableList<ListrectanglefortyoneRowModel>> =
      MutableLiveData(mutableListOf())
}
