package com.kikanissasapplication.app.modules.loginpagetwo.`data`.model

import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.di.MyApp
import kotlin.String

data class LoginPageTwoModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtDaftarKeECI: String? = MyApp.getInstance().resources.getString(R.string.lbl_daftar_ke_eci)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSayaingindaft: String? =
      MyApp.getInstance().resources.getString(R.string.msg_saya_ingin_daft)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtJamaah: String? = MyApp.getInstance().resources.getString(R.string.lbl_jamaah)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPengurus: String? = MyApp.getInstance().resources.getString(R.string.lbl_pengurus)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtEspacedeCulte: String? =
      MyApp.getInstance().resources.getString(R.string.msg_espace_de_culte)

)
