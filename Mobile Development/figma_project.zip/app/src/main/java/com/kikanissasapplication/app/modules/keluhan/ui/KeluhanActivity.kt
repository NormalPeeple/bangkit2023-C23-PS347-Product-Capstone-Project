package com.kikanissasapplication.app.modules.keluhan.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.base.BaseActivity
import com.kikanissasapplication.app.databinding.ActivityKeluhanBinding
import com.kikanissasapplication.app.modules.keluhan.`data`.viewmodel.KeluhanVM
import kotlin.String
import kotlin.Unit

class KeluhanActivity : BaseActivity<ActivityKeluhanBinding>(R.layout.activity_keluhan) {
  private val viewModel: KeluhanVM by viewModels<KeluhanVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.keluhanVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
  }

  companion object {
    const val TAG: String = "KELUHAN_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, KeluhanActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
