package com.kikanissasapplication.app.modules.updatesedekahsedekah.`data`.model

import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.di.MyApp
import kotlin.String

data class UpdateSedekahSedekahModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtUpdatePengguna: String? =
      MyApp.getInstance().resources.getString(R.string.msg_update_pengguna)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDanaUntukPeng: String? =
      MyApp.getInstance().resources.getString(R.string.msg_dana_untuk_peng)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBiayaTransaksi: String? =
      MyApp.getInstance().resources.getString(R.string.msg_biaya_transaksi2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSudahDIcairkan: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_sudah_dicairkan2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDicairkan: String? = MyApp.getInstance().resources.getString(R.string.lbl_rp5_125_000)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBelumDicairkan: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_belum_dicairkan)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var etUsernameValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etUsernameOneValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etGroupThirtyOneValue: String? = null
)
