package com.kikanissasapplication.app.modules.loginpageone.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.kikanissasapplication.app.modules.loginpageone.`data`.model.LoginPageOneModel
import org.koin.core.KoinComponent

class LoginPageOneVM : ViewModel(), KoinComponent {
  val loginPageOneModel: MutableLiveData<LoginPageOneModel> = MutableLiveData(LoginPageOneModel())

  var navArguments: Bundle? = null
}
