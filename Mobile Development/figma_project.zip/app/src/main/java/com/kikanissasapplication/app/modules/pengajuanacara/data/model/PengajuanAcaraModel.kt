package com.kikanissasapplication.app.modules.pengajuanacara.`data`.model

import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.di.MyApp
import kotlin.String

data class PengajuanAcaraModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtPengajuanAcara: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_pengajuan_acara)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNamaAcara: String? = MyApp.getInstance().resources.getString(R.string.lbl_nama_acara)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTanggalMulaiA: String? =
      MyApp.getInstance().resources.getString(R.string.msg_tanggal_mulai_a)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTanggalSelesai: String? =
      MyApp.getInstance().resources.getString(R.string.msg_tanggal_selesai2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNamaPenanggung: String? =
      MyApp.getInstance().resources.getString(R.string.msg_nama_penanggung)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtJabatanPenangg: String? =
      MyApp.getInstance().resources.getString(R.string.msg_jabatan_penangg)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtUnggahSuratIz: String? =
      MyApp.getInstance().resources.getString(R.string.msg_unggah_surat_iz)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTambahkanFile: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_tambahkan_file)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var etUsernameValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etUsernameOneValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etUsernameTwoValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etUsernameThreeValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etGroupThirtyFiveValue: String? = null
)
