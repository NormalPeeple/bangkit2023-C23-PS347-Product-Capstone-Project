package com.kikanissasapplication.app.modules.listdonasi.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.base.BaseActivity
import com.kikanissasapplication.app.databinding.ActivityListDonasiBinding
import com.kikanissasapplication.app.modules.listdonasi.`data`.viewmodel.ListDonasiVM
import kotlin.String
import kotlin.Unit

class ListDonasiActivity : BaseActivity<ActivityListDonasiBinding>(R.layout.activity_list_donasi) {
  private val viewModel: ListDonasiVM by viewModels<ListDonasiVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.listDonasiVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
  }

  companion object {
    const val TAG: String = "LIST_DONASI_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, ListDonasiActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
