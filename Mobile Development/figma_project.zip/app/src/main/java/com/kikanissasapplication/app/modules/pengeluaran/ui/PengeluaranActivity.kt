package com.kikanissasapplication.app.modules.pengeluaran.ui

import androidx.activity.viewModels
import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.base.BaseActivity
import com.kikanissasapplication.app.databinding.ActivityPengeluaranBinding
import com.kikanissasapplication.app.modules.pengeluaran.`data`.viewmodel.PengeluaranVM
import kotlin.String
import kotlin.Unit

class PengeluaranActivity : BaseActivity<ActivityPengeluaranBinding>(R.layout.activity_pengeluaran)
    {
  private val viewModel: PengeluaranVM by viewModels<PengeluaranVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.pengeluaranVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
  }

  companion object {
    const val TAG: String = "PENGELUARAN_ACTIVITY"

  }
}
