package com.kikanissasapplication.app.modules.listsedekah.`data`.model

import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.di.MyApp
import kotlin.String

data class ListSedekahModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtPengajuanSedek: String? =
      MyApp.getInstance().resources.getString(R.string.msg_pengajuan_sedek)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDaftarKeluhan: String? =
      MyApp.getInstance().resources.getString(R.string.msg_daftar_keluhan)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtToiletRusak: String? = MyApp.getInstance().resources.getString(R.string.lbl_toilet_rusak)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAbdulJaenal: String? = MyApp.getInstance().resources.getString(R.string.lbl_abdul_jaenal)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDeskripsi: String? = MyApp.getInstance().resources.getString(R.string.lbl_deskripsi)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtToiletrusakda: String? =
      MyApp.getInstance().resources.getString(R.string.msg_toilet_rusak_da)

)
