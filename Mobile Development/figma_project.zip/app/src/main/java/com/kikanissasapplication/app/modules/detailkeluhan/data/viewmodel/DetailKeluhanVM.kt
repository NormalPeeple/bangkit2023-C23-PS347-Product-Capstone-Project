package com.kikanissasapplication.app.modules.detailkeluhan.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.kikanissasapplication.app.modules.detailkeluhan.`data`.model.DetailKeluhanModel
import org.koin.core.KoinComponent

class DetailKeluhanVM : ViewModel(), KoinComponent {
  val detailKeluhanModel: MutableLiveData<DetailKeluhanModel> =
      MutableLiveData(DetailKeluhanModel())

  var navArguments: Bundle? = null
}
