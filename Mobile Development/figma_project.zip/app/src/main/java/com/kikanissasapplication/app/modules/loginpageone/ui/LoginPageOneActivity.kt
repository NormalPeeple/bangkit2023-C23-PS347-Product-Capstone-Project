package com.kikanissasapplication.app.modules.loginpageone.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.base.BaseActivity
import com.kikanissasapplication.app.databinding.ActivityLoginPageOneBinding
import com.kikanissasapplication.app.modules.loginpageone.`data`.viewmodel.LoginPageOneVM
import com.kikanissasapplication.app.modules.loginpagetwo.ui.LoginPageTwoActivity
import kotlin.String
import kotlin.Unit

class LoginPageOneActivity :
    BaseActivity<ActivityLoginPageOneBinding>(R.layout.activity_login_page_one) {
  private val viewModel: LoginPageOneVM by viewModels<LoginPageOneVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.loginPageOneVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.btnRegistrasi.setOnClickListener {
      val destIntent = LoginPageTwoActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "LOGIN_PAGE_ONE_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, LoginPageOneActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
