package com.kikanissasapplication.app.modules.loginpagetwo.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.kikanissasapplication.app.modules.loginpagetwo.`data`.model.LoginPageTwoModel
import org.koin.core.KoinComponent

class LoginPageTwoVM : ViewModel(), KoinComponent {
  val loginPageTwoModel: MutableLiveData<LoginPageTwoModel> = MutableLiveData(LoginPageTwoModel())

  var navArguments: Bundle? = null
}
