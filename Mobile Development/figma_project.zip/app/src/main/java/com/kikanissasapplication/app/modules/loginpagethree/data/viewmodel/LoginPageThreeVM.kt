package com.kikanissasapplication.app.modules.loginpagethree.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.kikanissasapplication.app.modules.loginpagethree.`data`.model.LoginPageThreeModel
import org.koin.core.KoinComponent

class LoginPageThreeVM : ViewModel(), KoinComponent {
  val loginPageThreeModel: MutableLiveData<LoginPageThreeModel> =
      MutableLiveData(LoginPageThreeModel())

  var navArguments: Bundle? = null
}
