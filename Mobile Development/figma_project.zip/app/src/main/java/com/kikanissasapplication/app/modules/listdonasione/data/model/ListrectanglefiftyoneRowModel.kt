package com.kikanissasapplication.app.modules.listdonasione.`data`.model

import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.di.MyApp
import kotlin.String

data class ListrectanglefiftyoneRowModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtBantuanLongsor: String? =
      MyApp.getInstance().resources.getString(R.string.msg_bantuan_longsor)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGerejaKatolik: String? =
      MyApp.getInstance().resources.getString(R.string.msg_gereja_katolik)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTerkumpulOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_terkumpul)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSisaHariOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_sisa_hari)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtRpCounterOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_rp_7_780_000)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHariCounterOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_33_hari)

)
