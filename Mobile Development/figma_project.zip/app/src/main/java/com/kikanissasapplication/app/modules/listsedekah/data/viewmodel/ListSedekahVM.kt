package com.kikanissasapplication.app.modules.listsedekah.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.kikanissasapplication.app.modules.listsedekah.`data`.model.ListSedekahModel
import org.koin.core.KoinComponent

class ListSedekahVM : ViewModel(), KoinComponent {
  val listSedekahModel: MutableLiveData<ListSedekahModel> = MutableLiveData(ListSedekahModel())

  var navArguments: Bundle? = null
}
