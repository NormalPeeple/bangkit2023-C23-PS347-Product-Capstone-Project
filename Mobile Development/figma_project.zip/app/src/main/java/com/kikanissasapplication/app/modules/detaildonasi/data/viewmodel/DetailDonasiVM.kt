package com.kikanissasapplication.app.modules.detaildonasi.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.kikanissasapplication.app.modules.detaildonasi.`data`.model.DetailDonasiModel
import org.koin.core.KoinComponent

class DetailDonasiVM : ViewModel(), KoinComponent {
  val detailDonasiModel: MutableLiveData<DetailDonasiModel> = MutableLiveData(DetailDonasiModel())

  var navArguments: Bundle? = null
}
