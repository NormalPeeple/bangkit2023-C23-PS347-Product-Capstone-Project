package com.kikanissasapplication.app.modules.catatankeuangan.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.base.BaseActivity
import com.kikanissasapplication.app.databinding.ActivityCatatanKeuanganBinding
import com.kikanissasapplication.app.modules.catatankeuangan.`data`.viewmodel.CatatanKeuanganVM
import com.kikanissasapplication.app.modules.pemasukan.ui.PemasukanActivity
import kotlin.String
import kotlin.Unit

class CatatanKeuanganActivity :
    BaseActivity<ActivityCatatanKeuanganBinding>(R.layout.activity_catatan_keuangan) {
  private val viewModel: CatatanKeuanganVM by viewModels<CatatanKeuanganVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.catatanKeuanganVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
    binding.btnTambahCatatan.setOnClickListener {
      val destIntent = PemasukanActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "CATATAN_KEUANGAN_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, CatatanKeuanganActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
