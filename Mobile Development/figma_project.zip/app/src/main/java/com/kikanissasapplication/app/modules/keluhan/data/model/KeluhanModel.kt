package com.kikanissasapplication.app.modules.keluhan.`data`.model

import com.kikanissasapplication.app.R
import com.kikanissasapplication.app.appcomponents.di.MyApp
import kotlin.String

data class KeluhanModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtKeluhan: String? = MyApp.getInstance().resources.getString(R.string.lbl_keluhan)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNamaTempatIba: String? =
      MyApp.getInstance().resources.getString(R.string.msg_nama_tempat_iba)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNamaKeluhan: String? = MyApp.getInstance().resources.getString(R.string.lbl_nama_keluhan)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDeskipsi: String? = MyApp.getInstance().resources.getString(R.string.lbl_deskipsi)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtExToiletrus: String? = MyApp.getInstance().resources.getString(R.string.msg_ex_toilet_rus2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtUnggahFoto: String? = MyApp.getInstance().resources.getString(R.string.lbl_unggah_foto)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var etGroupTenValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etGroupValue: String? = null
)
